// Object literal

const student_1 = {
    firstName: "Julian",
    LastName: "Smith",
    school: "San Diego Global Knowledge University",
    hobbies: ["Reading", "Play videoGames", "Running"],
    address: {
        state: "BC",
        city: "Tijuana",
        street: "University 1234",
        zip: "25112"
    }
}

const student_2 = {
    firstName: "Jake",
    LastName: "Schultz",
    school: "San Diego Global Knowledge University",
    hobbies: ["Reading", "Play videoGames", "Running"],
    address: {
        state: "Earth",
        city: "World",
        street: "University 1234",
        zip: "25112"
    }
}

console.log(student_1.hobbies[1]); //play videoGames

var state = student_1.address.state
console.log(state); //BC


// Objective destructuring

var {firstName} = student_1; // Using properties as variables.
console.log(firstName); 

var {address:{state}} = student_1
console.log(student_1)

// Object constructor