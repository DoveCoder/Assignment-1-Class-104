//name, age, gender, breed, service, owner, phone
function displayInfo() {
    document.getElementById("info").innerHTML = `
    <h3>Welcome to ${saloon.name}</h3>
    <p>${saloon.address.state}, ${saloon.address.city}. ${saloon.address.street}, Zip: ${saloon.address.zip}</p>
    `;
}
displayInfo();

function displayPetInfo() {
    document.getElementById("petsInfo").innerHTML = `
    <p>You have ${saloon.pets.length} pets that need to be serviced.</p>
    `;
}
displayPetInfo();


function displayPetsName() {
    for (let i = 0; i < saloon.pets.length; i++) {
        document.getElementById('petsName').innerHTML += `<p>${saloon.pets[i].name}</p>`;
    }
}
displayPetsName();
