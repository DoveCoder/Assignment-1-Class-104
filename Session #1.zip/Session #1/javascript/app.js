var saloon = {
    name: "The Fashion Pet",
    address: {
        state: "Vista",
        city: "CA",
        street: "The Fly Dog 1234",
        zip: "23981"
    },
    hours: {
        opening: "9:00 am",
        closing: "9:00 pm"
    },
    pets:[]
}


//Object Constructor!!!

// class Task {
//     constructor(description, priority) {
//         this.d = description;
//         this.p = priority;
//     }
// }
// var task1 = new Task("Play", "High");
// console.log(task1);
// var task2 = new Task("Nails", "Medium");
// console.log(task2);
// var task3 = new Task("Do Homework", "High");
// console.log(task3);

class Pet {
    constructor(name, age, gender, breed, service, owner, phone) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.breed = breed;
        this.service = service;
        this.owner = owner;
        this.phone = phone;
    }
}
// Create pets

var scooby = new Pet("Scooby", 60, "Male", "Dane", "Grooming", "Shagy", "555-555-5555");
saloon.pets.push(scooby);
var scrappy = new Pet("Scrappy", 50, "Male", "Mixed", "Nails cut", "Shaggy", "555-555-5555");
saloon.pets.push(scrappy);
var renosuke = new Pet("Renosuke", 2, "Male", "Akita", "Grooming", "Julian", "555-555-5555");
saloon.pets.push(renosuke);

// Gets info from form and converts to variables

var txtName = document.getElementById('petName');
var txtAge = document.getElementById('petAge');
var txtGender = document.getElementById('petGender');
var txtBreed = document.getElementById('petBreed');
var txtService = document.getElementById('petService');
var txtOwner = document.getElementById('ownerName');
var txtPhone = document.getElementById('ownerPhone');

// Function for registering a pet.

function register() {
    var thePet = new Pet(txtName.value, txtAge.value, txtGender.value, txtBreed.value, txtService.value, txtOwner.value, txtPhone.value);

    console.log(thePet);
    saloon.pets.push(thePet);
}

// Function clears the registered pet.

function clear() {
    txtName.value = ''; // Clearing the input field
    txtAge.value = '';
    txtGender.value = '';
    txtBreed.value = '';
    txtService.value = '';
    txtOwner.value = '';
    txtPhone.value = '';
}
